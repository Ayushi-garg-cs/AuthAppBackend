package com.auth_app_backend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http.csrf(AbstractHttpConfigurer::disable);
        http.authorizeHttpRequests(authorizeRequests -> authorizeRequests
                        .requestMatchers("/api/v1/auth/register").permitAll()
                .requestMatchers("/api/v1/auth/login").permitAll()
                .anyRequest().authenticated()
        )
                .httpBasic(Customizer.withDefaults());
        return http.build();
    }
    //this bean will used to fetch users
    //we have overwrite user and password jo log m aata tha ab passowrd log m ayega bhi nhi and usse api access bhi nhi hogi postman m
    //isme humne jo "User" use kiya h vo spring security se provided h but we want our own user entity class jo login kr rha hoga
    //when u'll open spring security User class it was implementing UserDetails class so why not we implement UserDetails in our own User entity
//    @Bean
//    public UserDetailsService user(){
//        User.UserBuilder userBuilder= User.withDefaultPasswordEncoder();
//        UserDetails user1=userBuilder.username("Ayushi").password("Ayushi@123").roles("ADMIN").build();
//        UserDetails user2=userBuilder.username("Uday").password("Uday@123").roles("ADMIN").build();
//        UserDetails user3=userBuilder.username("Sana").password("Sana@123").roles("USER").build();
//        return  new InMemoryUserDetailsManager(user1,user2,user3);
//    }

    //User implements UserDetails//our own User entity

}
